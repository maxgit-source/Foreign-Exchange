import Hero from "../components/home/Hero";
import FeaturedProducts from "../components/home/FeaturedProducts";
import CategoryExplorer from "../components/home/CategoryExplorer";
import { motion } from "framer-motion";
import { Truck, Shield, CreditCard } from "lucide-react";

const benefits = [
  { icon: Truck, title: "Envío rápido", desc: "Llega en 24-48hs a todo el país" },
  { icon: Shield, title: "Compra segura", desc: "Tus datos siempre protegidos" },
  { icon: CreditCard, title: "Múltiples pagos", desc: "Efectivo, transferencia y tarjeta" },
];

export default function Home() {
  return (
    <div>
      <Hero />

      {/* Benefits strip */}
      <section className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
            {benefits.map((b, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.15 }}
                className="flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                  <b.icon className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">{b.title}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">{b.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <FeaturedProducts />
      <CategoryExplorer />

      {/* CTA Banner */}
      <section className="py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative overflow-hidden rounded-3xl"
          >
            <img
              src="https://images.unsplash.com/photo-1490114538077-0a7f8cb49891?w=1400"
              alt="Banner"
              className="w-full h-72 sm:h-96 object-cover"
            />
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-center px-4">
              <div>
                <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white">
                  Tu estilo, tu identidad
                </h2>
                <p className="text-white/70 mt-4 text-sm sm:text-base max-w-md mx-auto">
                  Ropa casual pensada para vos. Calidad que se nota, precios que se agradecen.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
