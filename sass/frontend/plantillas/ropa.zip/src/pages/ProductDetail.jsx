import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { ShoppingCart, ChevronLeft, Check, Truck, RotateCcw, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import ProductImageGallery from "../components/products/ProductImageGallery";

export default function ProductDetail() {
  const { id } = useParams();
  const { toast } = useToast();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    const load = async () => {
      const data = await base44.entities.Product.filter({ id });
      if (data.length > 0) setProduct(data[0]);
      setLoading(false);
    };
    load();
  }, [id]);

  const addToCart = async () => {
    setAdding(true);
    await base44.entities.CartItem.create({
      product_id: product.id,
      product_name: product.name,
      product_image: product.images?.[0] || "",
      price: product.price,
      quantity: 1,
      size: selectedSize,
      color: selectedColor,
    });
    toast({
      title: "¡Agregado al carrito!",
      description: product.name,
    });
    setAdding(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-muted border-t-foreground rounded-full animate-spin" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-lg text-muted-foreground">Producto no encontrado</p>
        <Link to="/productos" className="text-accent mt-4 inline-block text-sm font-medium">
          Volver a productos
        </Link>
      </div>
    );
  }

  const hasDiscount = product.original_price && product.original_price > product.price;
  const discountPercent = hasDiscount
    ? Math.round(((product.original_price - product.price) / product.original_price) * 100)
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
      {/* Breadcrumb */}
      <Link
        to="/productos"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
      >
        <ChevronLeft className="w-4 h-4" />
        Volver a productos
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-14">
        {/* Gallery */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <ProductImageGallery images={product.images} />
        </motion.div>

        {/* Info */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-col"
        >
          <div className="flex-1">
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-medium mb-2">
              {product.category}
            </p>
            <h1 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold">
              {product.name}
            </h1>

            {/* Price */}
            <div className="mt-4 flex items-baseline gap-3">
              <span className="text-2xl sm:text-3xl font-bold">
                ${product.price?.toLocaleString("es-AR")}
              </span>
              {hasDiscount && (
                <>
                  <span className="text-lg text-muted-foreground line-through">
                    ${product.original_price?.toLocaleString("es-AR")}
                  </span>
                  <span className="text-sm font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                    -{discountPercent}% OFF
                  </span>
                </>
              )}
            </div>

            {/* Description */}
            {product.description && (
              <p className="text-muted-foreground mt-4 leading-relaxed text-sm sm:text-base">
                {product.description}
              </p>
            )}

            {/* Sizes */}
            {product.sizes && product.sizes.length > 0 && (
              <div className="mt-6">
                <h4 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-3">
                  Talla
                </h4>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`min-w-[44px] h-11 px-4 rounded-xl text-sm font-medium transition-all ${
                        selectedSize === size
                          ? "bg-primary text-primary-foreground shadow-md"
                          : "bg-secondary hover:bg-secondary/80 text-foreground"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Colors */}
            {product.colors && product.colors.length > 0 && (
              <div className="mt-6">
                <h4 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-3">
                  Color {selectedColor && <span className="normal-case tracking-normal">— {selectedColor}</span>}
                </h4>
                <div className="flex flex-wrap gap-2">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`h-11 px-4 rounded-xl text-sm font-medium transition-all ${
                        selectedColor === color
                          ? "bg-primary text-primary-foreground shadow-md"
                          : "bg-secondary hover:bg-secondary/80 text-foreground"
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Stock */}
            {product.stock > 0 && (
              <div className="mt-4 flex items-center gap-1.5 text-sm text-green-600">
                <Check className="w-4 h-4" />
                <span>Stock disponible ({product.stock} unidades)</span>
              </div>
            )}
          </div>

          {/* Add to cart */}
          <div className="mt-8 space-y-4">
            <Button
              onClick={addToCart}
              disabled={adding}
              className="w-full h-14 text-sm font-semibold uppercase tracking-wider bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl"
            >
              <ShoppingCart className="w-5 h-5 mr-2" />
              {adding ? "Agregando..." : "Agregar al carrito"}
            </Button>

            {/* Guarantees */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-border">
              {[
                { icon: Truck, label: "Envío rápido" },
                { icon: RotateCcw, label: "Cambios gratis" },
                { icon: Shield, label: "Compra segura" },
              ].map((g, i) => (
                <div key={i} className="text-center">
                  <g.icon className="w-5 h-5 mx-auto text-muted-foreground mb-1" />
                  <p className="text-[10px] sm:text-xs text-muted-foreground">{g.label}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
