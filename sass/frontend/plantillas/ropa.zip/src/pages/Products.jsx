import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import ProductCard from "../components/products/ProductCard";
import ProductFilters from "../components/products/ProductFilters";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: "",
    minPrice: 0,
    maxPrice: 50000,
    sort: "newest",
  });

  // Read category from URL on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cat = params.get("categoria");
    if (cat) setFilters((f) => ({ ...f, category: cat }));
  }, []);

  useEffect(() => {
    const load = async () => {
      const [prods, cats] = await Promise.all([
        base44.entities.Product.list("-created_date", 100),
        base44.entities.Category.list(),
      ]);
      setProducts(prods);
      setCategories(cats);
      setLoading(false);
    };
    load();
  }, []);

  const filtered = useMemo(() => {
    let result = [...products];

    if (filters.category) {
      result = result.filter((p) => p.category === filters.category);
    }
    result = result.filter(
      (p) => p.price >= filters.minPrice && p.price <= filters.maxPrice
    );

    if (filters.sort === "price_asc") {
      result.sort((a, b) => a.price - b.price);
    } else if (filters.sort === "price_desc") {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }, [products, filters]);

  const activeCategory = categories.find((c) => c.slug === filters.category);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Header */}
      <div className="mb-8">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-3xl sm:text-4xl font-bold"
        >
          {activeCategory ? activeCategory.name : "Todos los productos"}
        </motion.h1>
        <p className="text-muted-foreground mt-2 text-sm">
          {filtered.length} {filtered.length === 1 ? "producto" : "productos"}
        </p>
      </div>

      <div className="flex gap-8">
        {/* Filters */}
        <ProductFilters
          categories={categories}
          filters={filters}
          onFilterChange={setFilters}
        />

        {/* Products grid */}
        <div className="flex-1">
          {/* Mobile filter button bar */}
          <div className="lg:hidden mb-4">
            <ProductFilters
              categories={categories}
              filters={filters}
              onFilterChange={setFilters}
            />
          </div>

          {loading ? (
            <div className="flex justify-center py-20">
              <div className="w-8 h-8 border-2 border-muted border-t-foreground rounded-full animate-spin" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-muted-foreground text-lg">No se encontraron productos</p>
              <p className="text-sm text-muted-foreground mt-2">
                Intentá cambiar los filtros
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {filtered.map((product, i) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
