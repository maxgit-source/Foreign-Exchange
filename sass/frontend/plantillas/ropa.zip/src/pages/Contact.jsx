import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Clock, Instagram, MessageCircle } from "lucide-react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const contactInfo = [
  { icon: MapPin, label: "Dirección", value: "Av. Santa Fe 1234, CABA, Buenos Aires" },
  { icon: Phone, label: "WhatsApp", value: "+54 11 1234-5678" },
  { icon: Mail, label: "Email", value: "info@tutienda.com" },
  { icon: Clock, label: "Horario", value: "Lun-Vie 9:00 - 18:00 | Sáb 10:00 - 14:00" },
  { icon: Instagram, label: "Instagram", value: "@tutienda" },
];

export default function Contact() {
  const position = [-34.5957, -58.3974]; // Buenos Aires

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-12 sm:mb-16"
      >
        <p className="text-accent text-sm uppercase tracking-[0.3em] font-medium mb-3">
          Estamos para ayudarte
        </p>
        <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold">
          Contacto
        </h1>
        <p className="text-muted-foreground mt-4 max-w-md mx-auto text-sm sm:text-base">
          ¿Tenés alguna consulta? No dudes en contactarnos por cualquiera de estos medios.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
        {/* Contact cards */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="space-y-4"
        >
          {contactInfo.map((info, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }}
              className="flex items-start gap-4 p-5 rounded-2xl bg-card border border-border/50 hover:border-accent/30 hover:shadow-md transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                <info.icon className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold text-sm">{info.label}</h3>
                <p className="text-muted-foreground text-sm mt-0.5">{info.value}</p>
              </div>
            </motion.div>
          ))}

          {/* WhatsApp CTA */}
          <motion.a
            href="https://wa.me/5411123456789"
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.8 }}
            className="flex items-center justify-center gap-3 w-full py-4 rounded-2xl bg-green-600 text-white font-semibold text-sm uppercase tracking-wider hover:bg-green-700 transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            Escribinos por WhatsApp
          </motion.a>
        </motion.div>

        {/* Map */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="rounded-2xl overflow-hidden border border-border/50 shadow-sm h-[400px] lg:h-full lg:min-h-[500px]"
        >
          <MapContainer
            center={position}
            zoom={15}
            scrollWheelZoom={false}
            className="w-full h-full"
            style={{ height: "100%", width: "100%" }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Marker position={position}>
              <Popup>
                <strong>Tu Tienda</strong><br />
                Av. Santa Fe 1234, CABA
              </Popup>
            </Marker>
          </MapContainer>
        </motion.div>
      </div>
    </div>
  );
}
