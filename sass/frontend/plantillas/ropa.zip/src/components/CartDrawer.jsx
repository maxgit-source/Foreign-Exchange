import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function CartDrawer({ open, onClose }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open) loadItems();
  }, [open]);

  useEffect(() => {
    const unsub = base44.entities.CartItem.subscribe(() => {
      if (open) loadItems();
    });
    return unsub;
  }, [open]);

  const loadItems = async () => {
    setLoading(true);
    const data = await base44.entities.CartItem.list();
    setItems(data);
    setLoading(false);
  };

  const updateQuantity = async (item, delta) => {
    const newQty = (item.quantity || 1) + delta;
    if (newQty <= 0) {
      await base44.entities.CartItem.delete(item.id);
    } else {
      await base44.entities.CartItem.update(item.id, { quantity: newQty });
    }
    loadItems();
  };

  const removeItem = async (item) => {
    await base44.entities.CartItem.delete(item.id);
    loadItems();
  };

  const total = items.reduce((sum, i) => sum + i.price * (i.quantity || 1), 0);

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md flex flex-col">
        <SheetHeader>
          <SheetTitle className="font-display text-xl">Tu Carrito</SheetTitle>
        </SheetHeader>

        {loading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-muted border-t-foreground rounded-full animate-spin" />
          </div>
        ) : items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center gap-4">
            <ShoppingBag className="w-16 h-16 text-muted-foreground/30" />
            <div>
              <p className="font-medium">Tu carrito está vacío</p>
              <p className="text-sm text-muted-foreground mt-1">
                Explorá nuestros productos y agregá lo que te guste
              </p>
            </div>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto space-y-4 py-4">
              {items.map((item) => (
                <div key={item.id} className="flex gap-3 p-3 rounded-xl bg-secondary/50">
                  {item.product_image && (
                    <img
                      src={item.product_image}
                      alt={item.product_name}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                  )}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm truncate">{item.product_name}</h4>
                    {(item.size || item.color) && (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {[item.size, item.color].filter(Boolean).join(" · ")}
                      </p>
                    )}
                    <p className="font-semibold text-sm mt-1">
                      ${item.price?.toLocaleString("es-AR")}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <button
                        onClick={() => updateQuantity(item, -1)}
                        className="w-7 h-7 rounded-full bg-background border border-border flex items-center justify-center hover:bg-secondary transition-colors"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-sm font-medium w-6 text-center">
                        {item.quantity || 1}
                      </span>
                      <button
                        onClick={() => updateQuantity(item, 1)}
                        className="w-7 h-7 rounded-full bg-background border border-border flex items-center justify-center hover:bg-secondary transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => removeItem(item)}
                        className="ml-auto text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-border pt-4 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Total</span>
                <span className="text-xl font-bold">
                  ${total.toLocaleString("es-AR")}
                </span>
              </div>
              <Button className="w-full h-12 text-sm font-semibold uppercase tracking-wider bg-accent text-accent-foreground hover:bg-accent/90">
                Finalizar compra
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
