import { useState } from "react";
import { Link } from "react-router-dom";
import { Heart } from "lucide-react";

export default function ProductCard({ product }) {
  const [imgIndex, setImgIndex] = useState(0);
  const [liked, setLiked] = useState(false);
  const images = product.images || [];
  const hasDiscount = product.original_price && product.original_price > product.price;
  const discountPercent = hasDiscount
    ? Math.round(((product.original_price - product.price) / product.original_price) * 100)
    : 0;

  return (
    <Link
      to={`/productos/${product.id}`}
      className="group block"
    >
      <div className="relative overflow-hidden rounded-xl sm:rounded-2xl bg-secondary/50 aspect-[3/4]">
        {/* Image */}
        <img
          src={images[imgIndex] || "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400"}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />

        {/* Discount badge */}
        {hasDiscount && (
          <div className="absolute top-2.5 left-2.5 bg-accent text-accent-foreground text-[10px] sm:text-xs font-bold px-2 py-1 rounded-full">
            -{discountPercent}%
          </div>
        )}

        {/* Like button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            setLiked(!liked);
          }}
          className="absolute top-2.5 right-2.5 w-8 h-8 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              liked ? "fill-red-500 text-red-500" : "text-gray-600"
            }`}
          />
        </button>

        {/* Image dots */}
        {images.length > 1 && (
          <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex gap-1">
            {images.map((_, i) => (
              <button
                key={i}
                onClick={(e) => {
                  e.preventDefault();
                  setImgIndex(i);
                }}
                className={`w-1.5 h-1.5 rounded-full transition-all ${
                  i === imgIndex ? "bg-white w-4" : "bg-white/50"
                }`}
              />
            ))}
          </div>
        )}

        {/* Hover image navigation */}
        {images.length > 1 && (
          <div className="absolute inset-0 flex opacity-0 group-hover:opacity-100 transition-opacity">
            <div
              className="w-1/2 cursor-pointer"
              onClick={(e) => {
                e.preventDefault();
                setImgIndex(Math.max(0, imgIndex - 1));
              }}
            />
            <div
              className="w-1/2 cursor-pointer"
              onClick={(e) => {
                e.preventDefault();
                setImgIndex(Math.min(images.length - 1, imgIndex + 1));
              }}
            />
          </div>
        )}
      </div>

      {/* Info */}
      <div className="mt-3 px-0.5">
        <h3 className="font-medium text-sm sm:text-base truncate group-hover:text-accent transition-colors">
          {product.name}
        </h3>
        <div className="flex items-center gap-2 mt-1">
          <span className="font-bold text-sm sm:text-base">
            ${product.price?.toLocaleString("es-AR")}
          </span>
          {hasDiscount && (
            <span className="text-muted-foreground line-through text-xs sm:text-sm">
              ${product.original_price?.toLocaleString("es-AR")}
            </span>
          )}
        </div>
        {product.colors && product.colors.length > 0 && (
          <p className="text-xs text-muted-foreground mt-1">
            {product.colors.length} {product.colors.length === 1 ? "color" : "colores"}
          </p>
        )}
      </div>
    </Link>
  );
}
