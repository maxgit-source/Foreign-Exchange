import { useState } from "react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { SlidersHorizontal, X } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

export default function ProductFilters({ categories, filters, onFilterChange, maxPrice = 50000 }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const FilterContent = () => (
    <div className="space-y-8">
      {/* Categories */}
      <div>
        <h4 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-3">
          Categoría
        </h4>
        <div className="space-y-1">
          <button
            onClick={() => onFilterChange({ ...filters, category: "" })}
            className={`block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
              !filters.category
                ? "bg-accent/10 text-accent font-medium"
                : "text-foreground/70 hover:bg-secondary"
            }`}
          >
            Todas
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                onFilterChange({ ...filters, category: cat.slug });
                setMobileOpen(false);
              }}
              className={`block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                filters.category === cat.slug
                  ? "bg-accent/10 text-accent font-medium"
                  : "text-foreground/70 hover:bg-secondary"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <h4 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-3">
          Rango de precio
        </h4>
        <div className="px-2">
          <Slider
            min={0}
            max={maxPrice}
            step={500}
            value={[filters.minPrice || 0, filters.maxPrice || maxPrice]}
            onValueChange={([min, max]) =>
              onFilterChange({ ...filters, minPrice: min, maxPrice: max })
            }
            className="mb-3"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>${(filters.minPrice || 0).toLocaleString("es-AR")}</span>
            <span>${(filters.maxPrice || maxPrice).toLocaleString("es-AR")}</span>
          </div>
        </div>
      </div>

      {/* Sort */}
      <div>
        <h4 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-3">
          Ordenar por
        </h4>
        <div className="space-y-1">
          {[
            { value: "newest", label: "Más recientes" },
            { value: "price_asc", label: "Menor precio" },
            { value: "price_desc", label: "Mayor precio" },
          ].map((opt) => (
            <button
              key={opt.value}
              onClick={() => {
                onFilterChange({ ...filters, sort: opt.value });
                setMobileOpen(false);
              }}
              className={`block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                filters.sort === opt.value
                  ? "bg-accent/10 text-accent font-medium"
                  : "text-foreground/70 hover:bg-secondary"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Clear */}
      {(filters.category || filters.minPrice || filters.sort !== "newest") && (
        <Button
          variant="outline"
          className="w-full"
          onClick={() => {
            onFilterChange({ category: "", minPrice: 0, maxPrice, sort: "newest" });
            setMobileOpen(false);
          }}
        >
          <X className="w-4 h-4 mr-2" />
          Limpiar filtros
        </Button>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop */}
      <aside className="hidden lg:block w-64 shrink-0">
        <div className="sticky top-28">
          <FilterContent />
        </div>
      </aside>

      {/* Mobile trigger */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            className="lg:hidden flex items-center gap-2"
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filtros
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-80">
          <SheetHeader>
            <SheetTitle className="font-display">Filtros</SheetTitle>
          </SheetHeader>
          <div className="mt-6">
            <FilterContent />
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
