import { X, SlidersHorizontal } from 'lucide-react';
import { Slider } from '@/components/ui/slider';

const categories = ['Zapatillas', 'Remeras', 'Pantalones', 'Camperas', 'Accesorios', 'Shorts'];
const brands = ['Nike', 'Adidas', 'Puma', 'Under Armour', 'New Balance', 'Reebok'];
const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '36', '37', '38', '39', '40', '41', '42', '43', '44'];

export default function ProductFilters({ filters, setFilters, onClose, isMobile }) {
  const updateFilter = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const toggleArrayFilter = (key, value) => {
    setFilters(prev => {
      const arr = prev[key] || [];
      return {
        ...prev,
        [key]: arr.includes(value) ? arr.filter(v => v !== value) : [...arr, value],
      };
    });
  };

  const clearFilters = () => {
    setFilters({ category: null, priceRange: [0, 200000], brands: [], sizes: [], sort: '-created_date' });
  };

  const activeCount = (filters.category ? 1 : 0) + (filters.brands?.length || 0) + (filters.sizes?.length || 0);

  return (
    <div className={`${isMobile ? '' : 'sticky top-24'}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4" />
          <h3 className="font-heading font-semibold">Filtros</h3>
          {activeCount > 0 && (
            <span className="text-xs bg-primary text-primary-foreground w-5 h-5 rounded-full flex items-center justify-center">
              {activeCount}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {activeCount > 0 && (
            <button onClick={clearFilters} className="text-xs text-primary hover:underline">
              Limpiar
            </button>
          )}
          {isMobile && onClose && (
            <button onClick={onClose} className="p-1.5 hover:bg-secondary rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Categories */}
      <div className="mb-8">
        <h4 className="text-sm font-medium mb-3">Categoría</h4>
        <div className="space-y-1">
          <button
            onClick={() => updateFilter('category', null)}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
              !filters.category ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-secondary'
            }`}
          >
            Todas
          </button>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => updateFilter('category', cat)}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                filters.category === cat ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-secondary'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div className="mb-8">
        <h4 className="text-sm font-medium mb-3">Precio</h4>
        <Slider
          value={filters.priceRange || [0, 200000]}
          onValueChange={(val) => updateFilter('priceRange', val)}
          min={0}
          max={200000}
          step={5000}
          className="my-4"
        />
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>${(filters.priceRange?.[0] || 0).toLocaleString()}</span>
          <span>${(filters.priceRange?.[1] || 200000).toLocaleString()}</span>
        </div>
      </div>

      {/* Brands */}
      <div className="mb-8">
        <h4 className="text-sm font-medium mb-3">Marca</h4>
        <div className="flex flex-wrap gap-2">
          {brands.map(brand => (
            <button
              key={brand}
              onClick={() => toggleArrayFilter('brands', brand)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                filters.brands?.includes(brand)
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              {brand}
            </button>
          ))}
        </div>
      </div>

      {/* Sizes */}
      <div className="mb-8">
        <h4 className="text-sm font-medium mb-3">Talle</h4>
        <div className="flex flex-wrap gap-2">
          {sizes.map(size => (
            <button
              key={size}
              onClick={() => toggleArrayFilter('sizes', size)}
              className={`w-10 h-10 rounded-lg text-xs font-medium flex items-center justify-center transition-all ${
                filters.sizes?.includes(size)
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              {size}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
