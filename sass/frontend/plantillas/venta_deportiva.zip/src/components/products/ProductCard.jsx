import { useState } from 'react';
import { Heart, ShoppingBag, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function ProductCard({ product }) {
  const [imgIndex, setImgIndex] = useState(0);
  const [hovered, setHovered] = useState(false);
  const images = product.images?.length > 0 ? product.images : [];
  const hasDiscount = product.original_price && product.original_price > product.price;
  const discount = hasDiscount
    ? Math.round(((product.original_price - product.price) / product.original_price) * 100)
    : 0;

  const handlePrev = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setImgIndex(prev => (prev > 0 ? prev - 1 : images.length - 1));
  };

  const handleNext = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setImgIndex(prev => (prev < images.length - 1 ? prev + 1 : 0));
  };

  return (
    <Link to={`/productos/${product.id}`}>
      <motion.div
        className="group relative bg-card rounded-2xl overflow-hidden border border-border/50 hover:border-border hover:shadow-xl transition-all duration-500"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        whileHover={{ y: -4 }}
      >
        {/* Image Container */}
        <div className="relative aspect-[3/4] bg-muted overflow-hidden">
          {images.length > 0 ? (
            <img
              src={images[imgIndex]}
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              <ShoppingBag className="w-12 h-12 opacity-20" />
            </div>
          )}

          {/* Image nav arrows */}
          {images.length > 1 && hovered && (
            <>
              <button
                onClick={handlePrev}
                className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md hover:bg-white transition-colors z-10"
              >
                <ChevronLeft className="w-4 h-4 text-black" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md hover:bg-white transition-colors z-10"
              >
                <ChevronRight className="w-4 h-4 text-black" />
              </button>
            </>
          )}

          {/* Image dots */}
          {images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
              {images.map((_, i) => (
                <div
                  key={i}
                  className={`w-1.5 h-1.5 rounded-full transition-all ${
                    i === imgIndex ? 'bg-white w-4' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2 z-10">
            {hasDiscount && (
              <span className="px-2.5 py-1 bg-destructive text-destructive-foreground text-[10px] font-bold uppercase rounded-lg">
                -{discount}%
              </span>
            )}
            {product.featured && (
              <span className="px-2.5 py-1 bg-primary text-primary-foreground text-[10px] font-bold uppercase rounded-lg">
                Destacado
              </span>
            )}
          </div>

          {/* Favorite */}
          <button
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
            className="absolute top-3 right-3 w-9 h-9 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-sm opacity-0 group-hover:opacity-100 transition-opacity z-10 hover:bg-white"
          >
            <Heart className="w-4 h-4" />
          </button>
        </div>

        {/* Info */}
        <div className="p-4">
          <p className="text-[11px] text-muted-foreground uppercase tracking-wide font-medium">{product.brand || product.category}</p>
          <h3 className="font-medium text-sm mt-1 truncate">{product.name}</h3>
          <div className="flex items-center gap-2 mt-2">
            <span className="font-heading font-bold text-lg">${product.price?.toLocaleString()}</span>
            {hasDiscount && (
              <span className="text-sm text-muted-foreground line-through">${product.original_price?.toLocaleString()}</span>
            )}
          </div>
          {product.colors?.length > 0 && (
            <div className="flex gap-1.5 mt-3">
              {product.colors.slice(0, 5).map(color => (
                <div
                  key={color}
                  className="w-4 h-4 rounded-full border border-border"
                  style={{ backgroundColor: color }}
                  title={color}
                />
              ))}
              {product.colors.length > 5 && (
                <span className="text-[10px] text-muted-foreground self-center">+{product.colors.length - 5}</span>
              )}
            </div>
          )}
        </div>
      </motion.div>
    </Link>
  );
}
