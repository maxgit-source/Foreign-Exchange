import { motion } from 'framer-motion';
import { Truck, Shield, RotateCcw, Headphones } from 'lucide-react';

const features = [
  { icon: Truck, label: 'Envío gratis', desc: 'En compras +$50.000' },
  { icon: Shield, label: 'Pago seguro', desc: 'Todas las tarjetas' },
  { icon: RotateCcw, label: 'Cambios gratis', desc: '30 días para cambiar' },
  { icon: Headphones, label: 'Soporte 24/7', desc: 'Siempre disponibles' },
];

export default function PromoBar() {
  return (
    <section className="py-16 border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((f, i) => (
            <motion.div
              key={f.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex flex-col items-center text-center gap-3"
            >
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <f.icon className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h4 className="font-heading font-semibold text-sm">{f.label}</h4>
                <p className="text-xs text-muted-foreground mt-0.5">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
