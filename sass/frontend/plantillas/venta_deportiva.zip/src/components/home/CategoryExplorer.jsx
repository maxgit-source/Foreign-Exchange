import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const categories = [
  {
    name: 'Zapatillas',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80',
    description: 'Running, training y lifestyle',
  },
  {
    name: 'Remeras',
    image: 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=600&q=80',
    description: 'Tecnología Dry-Fit',
  },
  {
    name: 'Pantalones',
    image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=600&q=80',
    description: 'Máximo confort',
  },
  {
    name: 'Camperas',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&q=80',
    description: 'Protección y estilo',
  },
  {
    name: 'Shorts',
    image: 'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=600&q=80',
    description: 'Libertad de movimiento',
  },
  {
    name: 'Accesorios',
    image: 'https://images.unsplash.com/photo-1556906781-9a412961c28c?w=600&q=80',
    description: 'Completá tu outfit',
  },
];

export default function CategoryExplorer() {
  return (
    <section className="py-20 sm:py-28 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-primary text-sm font-semibold uppercase tracking-widest"
          >
            Categorías
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-heading font-bold text-3xl sm:text-4xl mt-2"
          >
            Explorá por Categoría
          </motion.h2>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          {categories.map((cat, i) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
            >
              <Link
                to={`/productos?category=${cat.name}`}
                className={`group relative block overflow-hidden rounded-2xl ${
                  i === 0 ? 'md:row-span-2 aspect-[3/4] md:aspect-auto md:h-full' : 'aspect-[4/3]'
                }`}
              >
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-6">
                  <h3 className="font-heading font-bold text-white text-lg sm:text-xl">{cat.name}</h3>
                  <p className="text-white/60 text-sm mt-1">{cat.description}</p>
                  <div className="mt-3 flex items-center gap-1 text-white text-xs font-medium opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                    Explorar
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
