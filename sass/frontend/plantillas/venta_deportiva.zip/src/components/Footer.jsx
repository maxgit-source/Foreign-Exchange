import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, Mail, MapPin, Phone } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-heading font-bold text-lg">S</span>
              </div>
              <span className="font-heading font-bold text-xl">SportFit</span>
            </div>
            <p className="text-sm opacity-60 leading-relaxed">
              Tu destino para ropa deportiva de alta performance. Estilo, comodidad y calidad en cada prenda.
            </p>
            <div className="flex gap-3">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-background/10 hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-all duration-300">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-heading font-semibold mb-4">Navegación</h4>
            <div className="space-y-3">
              {[
                { label: 'Inicio', path: '/' },
                { label: 'Productos', path: '/productos' },
                { label: 'Contacto', path: '/contacto' },
              ].map(link => (
                <Link key={link.path} to={link.path} className="block text-sm opacity-60 hover:opacity-100 transition-opacity">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-heading font-semibold mb-4">Categorías</h4>
            <div className="space-y-3">
              {['Zapatillas', 'Remeras', 'Pantalones', 'Camperas', 'Accesorios', 'Shorts'].map(cat => (
                <Link key={cat} to={`/productos?category=${cat}`} className="block text-sm opacity-60 hover:opacity-100 transition-opacity">
                  {cat}
                </Link>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading font-semibold mb-4">Contacto</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm opacity-60">
                <MapPin className="w-4 h-4 shrink-0" />
                <span>Av. Corrientes 1234, CABA</span>
              </div>
              <div className="flex items-center gap-3 text-sm opacity-60">
                <Phone className="w-4 h-4 shrink-0" />
                <span>+54 11 1234-5678</span>
              </div>
              <div className="flex items-center gap-3 text-sm opacity-60">
                <Mail className="w-4 h-4 shrink-0" />
                <span>info@sportfit.com</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-background/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs opacity-40">&copy; 2026 SportFit. Todos los derechos reservados.</p>
          <div className="flex gap-6">
            <a href="#" className="text-xs opacity-40 hover:opacity-100 transition-opacity">Términos</a>
            <a href="#" className="text-xs opacity-40 hover:opacity-100 transition-opacity">Privacidad</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
