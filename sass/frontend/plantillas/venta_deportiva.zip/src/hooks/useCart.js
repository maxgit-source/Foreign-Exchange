import { useState, useEffect } from 'react';
import { getCart, getCartCount, getCartTotal, subscribeCart, addToCart, removeFromCart, updateQuantity, clearCart } from '../lib/cartStore';

export default function useCart() {
  const [cart, setCart] = useState(getCart());

  useEffect(() => {
    return subscribeCart(setCart);
  }, []);

  return {
    cart,
    cartCount: getCartCount(),
    cartTotal: getCartTotal(),
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
  };
}
