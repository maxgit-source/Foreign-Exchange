import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Heart, ShoppingBag, Truck, Shield, RotateCcw, ArrowLeft, Check } from 'lucide-react';
import { addToCart } from '../lib/cartStore';
import { useToast } from '@/components/ui/use-toast';

export default function ProductDetail() {
  const { id } = useParams();
  const { toast } = useToast();
  const [imgIndex, setImgIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);
  const [quantity, setQuantity] = useState(1);

  const { data: product, isLoading } = useQuery({
    queryKey: ['product', id],
    queryFn: async () => {
      const products = await base44.entities.Product.filter({ id });
      return products[0];
    },
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="aspect-square bg-muted rounded-2xl animate-pulse" />
          <div className="space-y-4">
            <div className="h-6 bg-muted rounded w-1/3 animate-pulse" />
            <div className="h-10 bg-muted rounded w-2/3 animate-pulse" />
            <div className="h-8 bg-muted rounded w-1/4 animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex flex-col items-center justify-center py-32">
        <p className="text-xl font-heading">Producto no encontrado</p>
        <Link to="/productos" className="text-primary mt-4 hover:underline">Volver a productos</Link>
      </div>
    );
  }

  const images = product.images?.length > 0 ? product.images : [];
  const hasDiscount = product.original_price && product.original_price > product.price;
  const discount = hasDiscount
    ? Math.round(((product.original_price - product.price) / product.original_price) * 100)
    : 0;

  const handleAddToCart = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
    toast({
      title: "Agregado al carrito",
      description: `${product.name} x${quantity}`,
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Back */}
      <Link
        to="/productos"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Volver a productos
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
        {/* Image Gallery */}
        <div className="space-y-4">
          {/* Main Image */}
          <div className="relative aspect-square bg-muted rounded-2xl overflow-hidden group">
            <AnimatePresence mode="wait">
              {images.length > 0 ? (
                <motion.img
                  key={imgIndex}
                  src={images[imgIndex]}
                  alt={product.name}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                  <ShoppingBag className="w-20 h-20 opacity-20" />
                </div>
              )}
            </AnimatePresence>

            {images.length > 1 && (
              <>
                <button
                  onClick={() => setImgIndex(i => (i > 0 ? i - 1 : images.length - 1))}
                  className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white"
                >
                  <ChevronLeft className="w-5 h-5 text-black" />
                </button>
                <button
                  onClick={() => setImgIndex(i => (i < images.length - 1 ? i + 1 : 0))}
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white"
                >
                  <ChevronRight className="w-5 h-5 text-black" />
                </button>
              </>
            )}

            {/* Badges */}
            {hasDiscount && (
              <span className="absolute top-4 left-4 px-3 py-1.5 bg-destructive text-destructive-foreground text-xs font-bold uppercase rounded-lg">
                -{discount}% OFF
              </span>
            )}
          </div>

          {/* Thumbnails */}
          {images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setImgIndex(i)}
                  className={`w-20 h-20 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                    i === imgIndex ? 'border-primary' : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div>
          <p className="text-sm text-primary font-semibold uppercase tracking-widest">{product.brand}</p>
          <h1 className="font-heading font-bold text-2xl sm:text-3xl lg:text-4xl mt-2">{product.name}</h1>
          <p className="text-sm text-muted-foreground mt-1">{product.category}</p>

          {/* Price */}
          <div className="flex items-baseline gap-3 mt-6">
            <span className="font-heading font-bold text-3xl">${product.price?.toLocaleString()}</span>
            {hasDiscount && (
              <span className="text-lg text-muted-foreground line-through">${product.original_price?.toLocaleString()}</span>
            )}
            {hasDiscount && (
              <span className="text-sm font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded-lg">{discount}% OFF</span>
            )}
          </div>

          {/* Description */}
          {product.description && (
            <p className="text-muted-foreground mt-6 leading-relaxed">{product.description}</p>
          )}

          {/* Colors */}
          {product.colors?.length > 0 && (
            <div className="mt-8">
              <h4 className="text-sm font-medium mb-3">
                Color {selectedColor && <span className="text-muted-foreground font-normal">— {selectedColor}</span>}
              </h4>
              <div className="flex gap-3">
                {product.colors.map(color => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`w-10 h-10 rounded-full border-2 transition-all flex items-center justify-center ${
                      selectedColor === color ? 'border-primary scale-110' : 'border-border'
                    }`}
                    style={{ backgroundColor: color }}
                  >
                    {selectedColor === color && <Check className="w-4 h-4 text-white drop-shadow-md" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sizes */}
          {product.sizes?.length > 0 && (
            <div className="mt-8">
              <h4 className="text-sm font-medium mb-3">Talle</h4>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`min-w-[48px] h-12 px-4 rounded-xl text-sm font-medium transition-all ${
                      selectedSize === size
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity + Add to cart */}
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <div className="flex items-center bg-secondary rounded-xl">
              <button
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="w-12 h-12 flex items-center justify-center text-lg font-medium hover:bg-secondary/80 rounded-l-xl transition-colors"
              >
                −
              </button>
              <span className="w-12 text-center font-medium">{quantity}</span>
              <button
                onClick={() => setQuantity(q => q + 1)}
                className="w-12 h-12 flex items-center justify-center text-lg font-medium hover:bg-secondary/80 rounded-r-xl transition-colors"
              >
                +
              </button>
            </div>

            <button
              onClick={handleAddToCart}
              className="flex-1 flex items-center justify-center gap-2 py-3.5 bg-primary text-primary-foreground rounded-xl font-heading font-semibold hover:opacity-90 transition-opacity min-w-[200px]"
            >
              <ShoppingBag className="w-5 h-5" />
              Agregar al Carrito
            </button>

            <button className="w-12 h-12 rounded-xl border border-border flex items-center justify-center hover:bg-secondary transition-colors">
              <Heart className="w-5 h-5" />
            </button>
          </div>

          {/* Benefits */}
          <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { icon: Truck, label: 'Envío gratis', desc: 'En compras +$50.000' },
              { icon: Shield, label: 'Garantía', desc: '12 meses' },
              { icon: RotateCcw, label: 'Cambio gratis', desc: '30 días' },
            ].map(b => (
              <div key={b.label} className="flex items-center gap-3 p-3 bg-secondary/50 rounded-xl">
                <b.icon className="w-5 h-5 text-primary shrink-0" />
                <div>
                  <p className="text-xs font-medium">{b.label}</p>
                  <p className="text-[11px] text-muted-foreground">{b.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
