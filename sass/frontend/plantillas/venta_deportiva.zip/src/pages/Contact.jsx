import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Twitter } from 'lucide-react';
import { motion } from 'framer-motion';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

const contactInfo = [
  {
    icon: MapPin,
    title: 'Dirección',
    lines: ['Av. Corrientes 1234', 'C1043 CABA, Argentina'],
  },
  {
    icon: Phone,
    title: 'Teléfono',
    lines: ['+54 11 1234-5678', '+54 11 8765-4321'],
  },
  {
    icon: Mail,
    title: 'Email',
    lines: ['info@sportfit.com', 'ventas@sportfit.com'],
  },
  {
    icon: Clock,
    title: 'Horarios',
    lines: ['Lun - Vie: 9:00 - 20:00', 'Sáb: 10:00 - 14:00'],
  },
];

export default function Contact() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
      {/* Header */}
      <div className="text-center mb-16">
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-primary text-sm font-semibold uppercase tracking-widest"
        >
          Contacto
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-heading font-bold text-3xl sm:text-5xl mt-3"
        >
          Estamos para ayudarte
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-muted-foreground mt-4 max-w-lg mx-auto"
        >
          Visitanos en nuestra tienda o contactanos por cualquiera de nuestros canales. Respondemos en menos de 24 horas.
        </motion.p>
      </div>

      {/* Contact Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
        {contactInfo.map((item, i) => (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-6 bg-card rounded-2xl border border-border/50 hover:border-primary/20 hover:shadow-lg transition-all duration-300 group"
          >
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
              <item.icon className="w-5 h-5 text-primary" />
            </div>
            <h3 className="font-heading font-semibold mb-2">{item.title}</h3>
            {item.lines.map((line, j) => (
              <p key={j} className="text-sm text-muted-foreground">{line}</p>
            ))}
          </motion.div>
        ))}
      </div>

      {/* Map */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="rounded-2xl overflow-hidden border border-border/50 h-[400px] sm:h-[500px]"
      >
        <MapContainer
          center={[-34.6037, -58.3816]}
          zoom={15}
          scrollWheelZoom={false}
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <Marker position={[-34.6037, -58.3816]}>
            <Popup>
              <div className="text-center">
                <strong>SportFit</strong>
                <br />
                Av. Corrientes 1234, CABA
              </div>
            </Popup>
          </Marker>
        </MapContainer>
      </motion.div>

      {/* Social */}
      <div className="mt-16 text-center">
        <h3 className="font-heading font-semibold text-lg mb-4">Seguinos en redes</h3>
        <div className="flex justify-center gap-4">
          {[
            { icon: Instagram, label: '@sportfit' },
            { icon: Facebook, label: 'SportFit' },
            { icon: Twitter, label: '@sportfit' },
          ].map(social => (
            <a
              key={social.label}
              href="#"
              className="group flex items-center gap-2 px-5 py-3 rounded-xl bg-secondary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
            >
              <social.icon className="w-5 h-5" />
              <span className="text-sm font-medium">{social.label}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
