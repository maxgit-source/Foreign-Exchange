import HeroSection from '../components/home/HeroSection';
import FeaturedProducts from '../components/home/FeaturedProducts';
import CategoryExplorer from '../components/home/CategoryExplorer';
import PromoBar from '../components/home/PromoBar';

export default function Home() {
  return (
    <div>
      <HeroSection />
      <PromoBar />
      <FeaturedProducts />
      <CategoryExplorer />
    </div>
  );
}
