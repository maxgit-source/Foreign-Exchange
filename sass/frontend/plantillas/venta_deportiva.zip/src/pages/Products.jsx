import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { SlidersHorizontal, Grid3x3, LayoutGrid, Search } from 'lucide-react';
import ProductCard from '../components/products/ProductCard';
import ProductFilters from '../components/products/ProductFilters';

export default function Products() {
  const urlParams = new URLSearchParams(window.location.search);
  const initialCategory = urlParams.get('category');

  const [filters, setFilters] = useState({
    category: initialCategory || null,
    priceRange: [0, 200000],
    brands: [],
    sizes: [],
    sort: '-created_date',
  });
  const [search, setSearch] = useState('');
  const [gridCols, setGridCols] = useState(3);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list('-created_date', 100),
  });

  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Category filter
    if (filters.category) {
      result = result.filter(p => p.category === filters.category);
    }

    // Price filter
    if (filters.priceRange) {
      result = result.filter(p => p.price >= filters.priceRange[0] && p.price <= filters.priceRange[1]);
    }

    // Brand filter
    if (filters.brands?.length > 0) {
      result = result.filter(p => filters.brands.includes(p.brand));
    }

    // Size filter
    if (filters.sizes?.length > 0) {
      result = result.filter(p => p.sizes?.some(s => filters.sizes.includes(s)));
    }

    // Search
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(p =>
        p.name?.toLowerCase().includes(q) ||
        p.brand?.toLowerCase().includes(q) ||
        p.category?.toLowerCase().includes(q)
      );
    }

    // Sort
    if (filters.sort === 'price_asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (filters.sort === 'price_desc') {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }, [products, filters, search]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-heading font-bold text-3xl sm:text-4xl">
          {filters.category || 'Todos los Productos'}
        </h1>
        <p className="text-muted-foreground mt-2">
          {filteredProducts.length} {filteredProducts.length === 1 ? 'producto' : 'productos'}
        </p>
      </div>

      {/* Search + Sort bar */}
      <div className="flex flex-wrap items-center gap-3 mb-8">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar productos..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-secondary rounded-xl text-sm border-0 focus:ring-2 focus:ring-primary/20 focus:outline-none transition-all"
          />
        </div>

        <select
          value={filters.sort}
          onChange={(e) => setFilters(f => ({ ...f, sort: e.target.value }))}
          className="px-4 py-2.5 bg-secondary rounded-xl text-sm border-0 focus:ring-2 focus:ring-primary/20 focus:outline-none appearance-none cursor-pointer"
        >
          <option value="-created_date">Más recientes</option>
          <option value="price_asc">Menor precio</option>
          <option value="price_desc">Mayor precio</option>
        </select>

        {/* Grid toggle (desktop) */}
        <div className="hidden lg:flex items-center gap-1 bg-secondary rounded-xl p-1">
          <button
            onClick={() => setGridCols(3)}
            className={`p-2 rounded-lg transition-colors ${gridCols === 3 ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
          >
            <Grid3x3 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setGridCols(4)}
            className={`p-2 rounded-lg transition-colors ${gridCols === 4 ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
        </div>

        {/* Mobile filter button */}
        <button
          onClick={() => setMobileFiltersOpen(true)}
          className="lg:hidden flex items-center gap-2 px-4 py-2.5 bg-secondary rounded-xl text-sm"
        >
          <SlidersHorizontal className="w-4 h-4" />
          Filtros
        </button>
      </div>

      <div className="flex gap-8">
        {/* Desktop Filters */}
        <div className="hidden lg:block w-64 shrink-0">
          <ProductFilters filters={filters} setFilters={setFilters} />
        </div>

        {/* Products Grid */}
        <div className="flex-1">
          {isLoading ? (
            <div className={`grid gap-6 ${gridCols === 4 ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'}`}>
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="aspect-[3/4] bg-muted rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-muted-foreground text-lg">No se encontraron productos</p>
              <p className="text-sm text-muted-foreground mt-1">Intentá ajustar los filtros</p>
            </div>
          ) : (
            <div className={`grid gap-6 ${gridCols === 4 ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'}`}>
              <AnimatePresence mode="popLayout">
                {filteredProducts.map((product) => (
                  <motion.div
                    key={product.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                  >
                    <ProductCard product={product} />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Filters Drawer */}
      <AnimatePresence>
        {mobileFiltersOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileFiltersOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed left-0 top-0 bottom-0 w-full max-w-sm bg-background z-50 overflow-y-auto p-6"
            >
              <ProductFilters
                filters={filters}
                setFilters={setFilters}
                onClose={() => setMobileFiltersOpen(false)}
                isMobile
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
