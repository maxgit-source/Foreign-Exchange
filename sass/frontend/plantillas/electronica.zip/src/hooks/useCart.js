import { useState, useEffect, useCallback } from "react";
import {
  getCart,
  addToCart as addItem,
  removeFromCart as removeItem,
  updateQuantity as updateQty,
  getCartCount,
  getCartTotal,
  clearCart as clearAll,
  subscribeToCart,
} from "../lib/cartStore";

export default function useCart() {
  const [, setTick] = useState(0);

  useEffect(() => {
    return subscribeToCart(() => setTick((t) => t + 1));
  }, []);

  const addToCart = useCallback((product, qty) => addItem(product, qty), []);
  const removeFromCart = useCallback((id) => removeItem(id), []);
  const updateQuantity = useCallback((id, qty) => updateQty(id, qty), []);
  const clearCart = useCallback(() => clearAll(), []);

  return {
    items: getCart(),
    count: getCartCount(),
    total: getCartTotal(),
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
  };
}
