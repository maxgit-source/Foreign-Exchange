import { Link } from "react-router-dom";
import { ArrowRight, Truck, Shield, Headphones } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
      <div className="absolute top-20 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/10 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-14 lg:pt-24 lg:pb-32">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-8 items-center">
          {/* Text */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-5 sm:space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs sm:text-sm font-medium">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              Nuevos lanzamientos 2026
            </div>

            <h1 className="font-space text-3xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
              Tecnología que{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                inspira
              </span>{" "}
              tu vida
            </h1>

            <p className="text-base sm:text-lg text-muted-foreground max-w-lg leading-relaxed">
              Descubre los productos electrónicos más innovadores del mercado.
              Calidad premium, precios irresistibles y envío gratuito en toda tu compra.
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
              <Link to="/productos" className="flex-1 sm:flex-none">
                <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-base rounded-xl font-semibold gap-2 group">
                  Explorar Tienda
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to="/productos?category=smartphones" className="flex-1 sm:flex-none">
                <Button variant="outline" size="lg" className="w-full sm:w-auto h-12 px-8 text-base rounded-xl font-semibold">
                  Ver Smartphones
                </Button>
              </Link>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-4 sm:gap-6 pt-2">
              {[
                { icon: Truck, label: "Envío Gratis" },
                { icon: Shield, label: "Garantía 2 Años" },
                { icon: Headphones, label: "Soporte 24/7" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                  <Icon className="w-4 h-4 text-primary" />
                  {label}
                </div>
              ))}
            </div>
          </motion.div>

          {/* Hero image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-2xl lg:rounded-3xl overflow-hidden aspect-video sm:aspect-square lg:aspect-auto lg:h-[520px]">
              <img
                src="https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=800&q=80"
                alt="Electronics showcase"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/20 via-transparent to-transparent" />
            </div>

            {/* Floating card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              className="absolute -bottom-4 left-3 sm:left-6 bg-card rounded-2xl shadow-2xl p-3 sm:p-5 border border-border/50"
            >
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-500/10 rounded-xl flex items-center justify-center">
                  <span className="text-xl sm:text-2xl">🔥</span>
                </div>
                <div>
                  <p className="font-semibold text-xs sm:text-sm">Ofertas del mes</p>
                  <p className="text-[10px] sm:text-xs text-muted-foreground">Hasta 40% de descuento</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
