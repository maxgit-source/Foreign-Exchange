import { useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { categories, brands } from "../../lib/storeData";
import { motion, AnimatePresence } from "framer-motion";

export default function ProductFilters({
  selectedCategory,
  onCategoryChange,
  priceRange,
  onPriceChange,
  selectedBrands,
  onBrandsChange,
}) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const toggleBrand = (brand) => {
    if (selectedBrands.includes(brand)) {
      onBrandsChange(selectedBrands.filter((b) => b !== brand));
    } else {
      onBrandsChange([...selectedBrands, brand]);
    }
  };

  const hasFilters =
    selectedCategory !== "all" ||
    priceRange[0] > 0 ||
    priceRange[1] < 3000 ||
    selectedBrands.length > 0;

  const clearAll = () => {
    onCategoryChange("all");
    onPriceChange([0, 3000]);
    onBrandsChange([]);
  };

  const filterContent = (
    <div className="space-y-8">
      {/* Categories */}
      <div>
        <h3 className="font-space font-semibold text-sm mb-4">Categorías</h3>
        <div className="space-y-1">
          <button
            onClick={() => onCategoryChange("all")}
            className={`w-full text-left px-3 py-2 rounded-xl text-sm transition-colors ${
              selectedCategory === "all"
                ? "bg-primary text-primary-foreground font-medium"
                : "hover:bg-secondary text-muted-foreground"
            }`}
          >
            Todos los productos
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onCategoryChange(cat.id)}
              className={`w-full text-left px-3 py-2 rounded-xl text-sm transition-colors ${
                selectedCategory === cat.id
                  ? "bg-primary text-primary-foreground font-medium"
                  : "hover:bg-secondary text-muted-foreground"
              }`}
            >
              {cat.name}
              <span className="ml-1 opacity-60">({cat.count})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Price range */}
      <div>
        <h3 className="font-space font-semibold text-sm mb-4">Rango de Precio</h3>
        <Slider
          min={0}
          max={3000}
          step={50}
          value={priceRange}
          onValueChange={onPriceChange}
          className="mb-4"
        />
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>USD {priceRange[0]}</span>
          <span>USD {priceRange[1]}</span>
        </div>
      </div>

      {/* Brands */}
      <div>
        <h3 className="font-space font-semibold text-sm mb-4">Marcas</h3>
        <div className="space-y-2">
          {brands.map((brand) => (
            <label
              key={brand}
              className="flex items-center gap-3 cursor-pointer group"
            >
              <div
                className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
                  selectedBrands.includes(brand)
                    ? "bg-primary border-primary"
                    : "border-border group-hover:border-primary/50"
                }`}
              >
                {selectedBrands.includes(brand) && (
                  <svg className="w-3 h-3 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </div>
              <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                {brand}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Clear filters */}
      {hasFilters && (
        <Button
          variant="outline"
          onClick={clearAll}
          className="w-full rounded-xl"
        >
          Limpiar filtros
        </Button>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:block w-64 flex-shrink-0">
        <div className="sticky top-24 bg-card rounded-2xl border border-border/50 p-6">
          <h2 className="font-space font-bold text-lg mb-6 flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5" />
            Filtros
          </h2>
          {filterContent}
        </div>
      </aside>

      {/* Mobile filter button */}
      <div className="lg:hidden mb-4">
        <Button
          variant="outline"
          onClick={() => setMobileOpen(true)}
          className="rounded-xl gap-2"
        >
          <SlidersHorizontal className="w-4 h-4" />
          Filtros
          {hasFilters && (
            <span className="w-5 h-5 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center">
              !
            </span>
          )}
        </Button>
      </div>

      {/* Mobile filter drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              className="lg:hidden fixed inset-0 z-50 bg-black/50"
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="lg:hidden fixed left-0 top-0 bottom-0 z-50 w-80 bg-card p-6 overflow-auto"
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="font-space font-bold text-lg flex items-center gap-2">
                  <SlidersHorizontal className="w-5 h-5" />
                  Filtros
                </h2>
                <button onClick={() => setMobileOpen(false)}>
                  <X className="w-5 h-5" />
                </button>
              </div>
              {filterContent}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
