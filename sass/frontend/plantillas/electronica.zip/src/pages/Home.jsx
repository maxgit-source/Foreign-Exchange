import HeroSection from "../components/home/HeroSection";
import FeaturedProducts from "../components/home/FeaturedProducts";
import CategoryExplorer from "../components/home/CategoryExplorer";

export default function Home() {
  return (
    <div>
      <HeroSection />
      <FeaturedProducts />
      <CategoryExplorer />
    </div>
  );
}
