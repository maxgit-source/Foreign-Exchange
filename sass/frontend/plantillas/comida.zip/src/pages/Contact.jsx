import { MapPin, Phone, Mail, Clock, Instagram, Facebook } from "lucide-react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { motion } from "framer-motion";
import "leaflet/dist/leaflet.css";

const CONTACT_INFO = [
  {
    icon: MapPin,
    title: "Dirección",
    details: ["Av. Principal 1234", "Col. Centro, CDMX, México"],
  },
  {
    icon: Phone,
    title: "Teléfono",
    details: ["+52 55 1234 5678", "+52 55 9876 5432"],
  },
  {
    icon: Mail,
    title: "Email",
    details: ["hola@burgerlab.com", "pedidos@burgerlab.com"],
  },
  {
    icon: Clock,
    title: "Horario",
    details: ["Lun-Jue: 11:00 - 22:00", "Vie-Sáb: 11:00 - 00:00", "Dom: 12:00 - 21:00"],
  },
];

export default function Contact() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-card/50 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
          <span className="text-primary text-sm font-semibold tracking-wider uppercase">
            Encuéntranos
          </span>
          <h1 className="font-heading text-3xl sm:text-4xl font-bold mt-2">
            Contacto
          </h1>
          <p className="text-muted-foreground mt-2 max-w-md">
            Estamos para atenderte. Visítanos o contáctanos por cualquiera de estos medios.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Contact Cards */}
          <div className="space-y-5">
            {CONTACT_INFO.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex gap-4 p-5 bg-card border border-border rounded-2xl hover:border-primary/30 transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-heading font-semibold text-base">{item.title}</h3>
                    <div className="mt-1 space-y-0.5">
                      {item.details.map((detail) => (
                        <p key={detail} className="text-sm text-muted-foreground">
                          {detail}
                        </p>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}

            {/* Social */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="p-5 bg-card border border-border rounded-2xl"
            >
              <h3 className="font-heading font-semibold text-base mb-3">Síguenos</h3>
              <div className="flex gap-3">
                <a
                  href="#"
                  className="flex items-center gap-2 px-4 py-2.5 bg-secondary rounded-xl text-sm font-medium hover:bg-primary/10 hover:text-primary transition-all"
                >
                  <Instagram className="w-4 h-4" />
                  Instagram
                </a>
                <a
                  href="#"
                  className="flex items-center gap-2 px-4 py-2.5 bg-secondary rounded-xl text-sm font-medium hover:bg-primary/10 hover:text-primary transition-all"
                >
                  <Facebook className="w-4 h-4" />
                  Facebook
                </a>
              </div>
            </motion.div>
          </div>

          {/* Map */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="h-[400px] lg:h-full min-h-[400px] rounded-2xl overflow-hidden border border-border"
          >
            <MapContainer
              center={[19.4326, -99.1332]}
              zoom={15}
              className="w-full h-full"
              scrollWheelZoom={false}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <Marker position={[19.4326, -99.1332]}>
                <Popup>
                  <strong>BurgerLab</strong>
                  <br />
                  Av. Principal 1234, CDMX
                </Popup>
              </Marker>
            </MapContainer>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
