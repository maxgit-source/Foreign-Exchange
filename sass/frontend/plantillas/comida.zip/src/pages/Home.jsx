import { useOutletContext } from "react-router-dom";
import HeroSection from "../components/home/HeroSection";
import FeaturedProducts from "../components/home/FeaturedProducts";
import CategoryExplorer from "../components/home/CategoryExplorer";

export default function Home() {
  const { addToCart } = useOutletContext();

  return (
    <div>
      <HeroSection />
      <FeaturedProducts addToCart={addToCart} />
      <CategoryExplorer />
    </div>
  );
}
