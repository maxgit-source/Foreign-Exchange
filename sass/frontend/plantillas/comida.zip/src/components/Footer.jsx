import { Link } from "react-router-dom";
import { Flame, Instagram, Facebook, MapPin, Phone, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center">
                <Flame className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-heading text-xl font-bold">
                Burger<span className="text-primary">Lab</span>
              </span>
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
              Hamburguesas artesanales preparadas con los mejores ingredientes. Una experiencia gastronómica única.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-heading font-semibold text-foreground mb-4">Navegación</h4>
            <ul className="space-y-2.5">
              {[
                { to: "/", label: "Inicio" },
                { to: "/productos", label: "Menú" },
                { to: "/contacto", label: "Contacto" },
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading font-semibold text-foreground mb-4">Contacto</h4>
            <ul className="space-y-2.5">
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4 text-primary flex-shrink-0" />
                Av. Principal 1234, CDMX
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="w-4 h-4 text-primary flex-shrink-0" />
                +52 55 1234 5678
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                hola@burgerlab.com
              </li>
            </ul>
          </div>

          {/* Horario */}
          <div>
            <h4 className="font-heading font-semibold text-foreground mb-4">Horario</h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li>Lun - Jue: 11:00 - 22:00</li>
              <li>Vie - Sáb: 11:00 - 00:00</li>
              <li>Domingo: 12:00 - 21:00</li>
            </ul>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-9 h-9 rounded-xl bg-secondary hover:bg-primary/10 hover:text-primary flex items-center justify-center transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-xl bg-secondary hover:bg-primary/10 hover:text-primary flex items-center justify-center transition-all">
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-10 pt-8 text-center">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} BurgerLab. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
