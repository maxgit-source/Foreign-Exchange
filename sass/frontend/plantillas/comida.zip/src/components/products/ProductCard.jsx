import { Link } from "react-router-dom";
import { ShoppingCart, Star, Eye } from "lucide-react";
import { motion } from "framer-motion";

export default function ProductCard({ product, addToCart, index = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="group"
    >
      <div className="bg-card rounded-2xl overflow-hidden border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 hover:-translate-y-1">
        {/* Image */}
        <Link to={`/producto/${product.id}`} className="block relative aspect-square overflow-hidden">
          <img
            src={product.images?.[0]}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

          {/* Hover overlay */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
            <div className="flex items-center gap-2 px-4 py-2 bg-background/90 backdrop-blur-sm rounded-xl text-sm font-medium">
              <Eye className="w-4 h-4" /> Ver Detalle
            </div>
          </div>

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.featured && (
              <span className="px-2.5 py-1 bg-primary text-primary-foreground text-xs font-bold rounded-lg">
                Popular
              </span>
            )}
            {product.original_price && product.original_price > product.price && (
              <span className="px-2.5 py-1 bg-destructive text-destructive-foreground text-xs font-bold rounded-lg">
                -{Math.round((1 - product.price / product.original_price) * 100)}%
              </span>
            )}
          </div>
        </Link>

        {/* Content */}
        <div className="p-4">
          <div className="flex items-center gap-1 mb-1.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3 h-3 text-primary fill-primary" />
            ))}
          </div>

          <Link to={`/producto/${product.id}`}>
            <h3 className="font-heading font-semibold text-base group-hover:text-primary transition-colors line-clamp-1">
              {product.name}
            </h3>
          </Link>

          <p className="text-xs text-muted-foreground mt-1 line-clamp-2 leading-relaxed">
            {product.description}
          </p>

          <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-bold text-primary">
                ${product.price?.toFixed(2)}
              </span>
              {product.original_price && product.original_price > product.price && (
                <span className="text-xs text-muted-foreground line-through">
                  ${product.original_price?.toFixed(2)}
                </span>
              )}
            </div>
            <button
              onClick={() => addToCart(product)}
              className="flex items-center gap-1.5 h-9 px-3 rounded-xl bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-all active:scale-95"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              Agregar
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
